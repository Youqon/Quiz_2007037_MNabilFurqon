<?php
include "koneksi.php";

$kode_barang = $_POST['kdbrg'];
$nama_barang = $_POST['nama'];
$stok = $_POST['stok'];
$harga = $_POST['hrg'];
$kategori = $_POST['ktg'];

$query_insert = mysqli_query($koneksi, "INSERT INTO barang VALUES('$kode_barang', '$nama_barang', '$stok', '$harga', '$kategori')");

if ($query_insert) {
    echo "Berhasil menambah data barang";
    header('Location: tampilandata.php');
} else {
    echo "Gagal menambah data barang";
}
