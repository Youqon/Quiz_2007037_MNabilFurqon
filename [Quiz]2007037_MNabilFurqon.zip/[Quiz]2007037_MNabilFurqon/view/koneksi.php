<?php
$username = "root";
$host = "localhost";
$password = "";
$nama_database = "db_farming";
$koneksi = mysqli_connect($host, $username, $password, $nama_database);
// if ($koneksi) {
//     echo "Koneksi database berhasil";
// }
