<?php
include "koneksi.php";

$kdbrg = $_GET['kodebrg']; // untuk mengambil data yang dikirim

$query = mysqli_query($koneksi, "delete from barang where kode_barang = '$kdbrg'");

if ($query) {
    header("Location:tampilandata.php"); // kembali ke halaman sebelumnya
} else {
    echo "data gagal delete";
}
