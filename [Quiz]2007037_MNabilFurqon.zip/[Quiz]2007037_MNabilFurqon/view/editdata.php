<?php
include "koneksi.php";

try {
    $kode_barang = $_POST['kdbrg'];
    $nama_barang = $_POST['nama'];
    $stok = $_POST['stok'];
    $harga = $_POST['hrg'];
    $kategori = $_POST['ktg'];
    
    $query_insert = mysqli_query($koneksi, "UPDATE barang t SET t.nama_barang = '" . $nama_barang . "', t.stok = " . $stok . ", t.harga       = " . $harga . ", t.kategori    = '" . $kategori . "' WHERE t.kode_barang LIKE '" . $kode_barang . "'; ");
    
    if ($query_insert) {
        echo "Berhasil menambah data barang";
        header('Location: tampilandata.php');
    } else {
        echo "Gagal menambah data barang";
        header('Location: tampilandata.php');
    }
} catch (Exception $e) {
    var_dump($e);
}
